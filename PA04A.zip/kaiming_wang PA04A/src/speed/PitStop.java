//Kaiming Wang
//PA#04A
//03/05/2020

package speed;

public class PitStop {
	
	private RaceCar[] car;
	private int num;
	
	public PitStop() {
		this.car = new RaceCar[10];
		this.num = 0; // use this number field to record how many race cars in total are in the race track
	}
	

	public void setCarForPS(RaceCar[] raceCars) {
		for (int i = 0; i < raceCars.length; i++) {
				car[i] = raceCars[i];
		}
		this.num = raceCars.length;
	}
	

	public void enterPitStop(RaceCar car) { 
		car.setTime(2);
		car.stop();
		car.repaired();
	}
	

	public void tick() {
		for (int i =0; i <num; i++) {
			this.car[i].setTime(this.car[i].getTime()-1);
		}
	}
	

	public void exitPitStop(RaceCar car) {
		car.recover();
		car.repaired();
	}
}
