//Kaiming Wang
//PA#04A
//03/05/2020

package speed;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class sets up and runs a RaceTrack with some user input initialization data. 
 * <p><b>You should not edit this file.</b></p>
 *  
 * @author cs12b
 * @version 2.0 
 */
public class SimulationDriver {


	public static final int DEFAULT_STAT_VAL = 0;
		
	/**
	 * @param args cmd line args not used 
	 * @see #getSomeRaceCars()
	 */
	public static void main(String[] args) {
		RaceTrack track = new RaceTrack();
		track.setCars(getSomeRaceCars());
		System.out.println("The race has started!");
		track.run();
	}
		

	public static RaceCar[] getSomeRaceCars() {
		System.out.println("Welcome to the Need for Speed Simulator!\n\nFor each RaceCar: enter the speed and strength separated by a space.\nIf you want to construct a default RaceCar, enter " + DEFAULT_STAT_VAL + " for the speed and strength.");
		Scanner consoleRdr = new Scanner(System.in);
		int numCars = -1;
		boolean carNumInvalid = true;
		

		do {
			System.out.print("How many RaceCars would you like to enter in the race? ");
			try { 
				numCars = consoleRdr.nextInt();
			} 
			catch (InputMismatchException e) {  
				System.out.println("Please enter a valid integer.");
				consoleRdr.nextLine();
				continue;
			}
			if (numCars >= 0) { 
				carNumInvalid = false;
			}
			else {
				System.out.println("Please enter a nonnegative integer.");
			}
		} while (carNumInvalid);
		System.out.println();
		
		RaceCar[] cars = new RaceCar[numCars];		
		for (int i = 0; i < numCars; i++) {
			boolean carInvalid = true;
			do {
				System.out.print("RaceCar #" + (i + 1) + ": ");
				int speed = -1;
				int strength = -1;
				try {
					speed = consoleRdr.nextInt();
					strength = consoleRdr.nextInt();
				}
				catch (InputMismatchException e) { 
					System.out.println("The strength and speed should be valid integers.");
					consoleRdr.nextLine();
					continue;
				}
					
				
				if (speed < 0 || strength < 0) { 
					System.out.println("The strength and speed should not be negative.");
					continue;
				}
				

				if ((speed != DEFAULT_STAT_VAL && strength == DEFAULT_STAT_VAL) || (speed == DEFAULT_STAT_VAL && strength != DEFAULT_STAT_VAL)) { 
					System.out.println("The strength and speed must either both be " + DEFAULT_STAT_VAL + " or both nonzero.");
					continue;
				}
				
				carInvalid = false; 
				if (speed == DEFAULT_STAT_VAL && strength == DEFAULT_STAT_VAL) {
					cars[i] = new RaceCar();
				}
				else {
					cars[i] = new RaceCar(speed, strength);
				}
				System.out.println();
				
			} while (carInvalid);		
		}
		consoleRdr.close();
		return cars;
	}
}
